# app.py — Smartwatch Fitness Tracker (Now with Current & Lost Weight)
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import joblib
from datetime import datetime, time
from model_train import STEP_LENGTH_M, SCALE

# ---------------- PAGE SETUP ----------------
st.set_page_config(page_title="AI Fitness Tracker", layout="centered")

# ---------------- THEME ----------------
st.markdown("""
<style>
[data-testid="stAppViewContainer"] {
    background-color: white !important;
}
[data-testid="stHeader"] { background: transparent; }
[data-testid="stSidebar"] { background-color: #f0f0f0 !important; }

/* Text styling */
.main-title {
    font-size: 44px;
    text-align: center;
    font-weight: bold;
    color: #333333;
    margin-bottom: -10px;
}
.subtext {
    text-align: center;
    color: #666666;
    margin-bottom: 20px;
}

/* Stat boxes */
.metric-box {
    background: linear-gradient(145deg, #e0f7e0, #b0f0b0);
    border: 1px solid #00FF7F40;
    padding: 25px;
    border-radius: 20px;
    text-align: center;
    box-shadow: 0px 0px 20px #00FF7F40;
    color: #333333;
}
.metric-label {
    font-size: 18px;
    font-weight: 600;
    color: #555555;
}
.metric-value {
    font-size: 30px;
    font-weight: bold;
    color: #006400;
}
.metric-unit {
    font-size: 16px;
    color: #555555;
}
</style>
""", unsafe_allow_html=True)

# ---------------- HEADER ----------------
st.markdown("<p class='main-title'>🏃 Smart AI Fitness Tracker</p>", unsafe_allow_html=True)
st.markdown("<p class='subtext'>Beautiful Smartwatch Dashboard with Weight Tracking and EvoCode LostWeight</p>", unsafe_allow_html=True)

# ---------------- SIDEBAR ----------------
st.sidebar.header("⚙️ Activity Settings")
weight = st.sidebar.number_input("Body Weight (kg)", min_value=30, max_value=150, value=65)
step_length = st.sidebar.number_input("Step Length (m)", min_value=0.4, max_value=1.0, value=float(STEP_LENGTH_M))
num_sessions = st.sidebar.slider("Number of Time Slots", 1, 8, 4)

# ---------------- USER INPUT ----------------
st.subheader("🕒 Enter Time & Step Count")

time_entries, step_entries = [], []
for i in range(num_sessions):
    col1, col2 = st.columns(2)
    with col1:
        t_in = st.time_input(f"Time {i+1}", value=time(8+i, 0), key=f"time_{i}")
        parsed_time = t_in.strftime("%H:%M")
    with col2:
        steps = st.number_input(f"Steps {i+1}", min_value=0, step=100, value=1000, key=f"steps_{i}")
    time_entries.append(parsed_time)
    step_entries.append(steps)

df = pd.DataFrame({"Time": time_entries, "Steps": step_entries})
df["Weight (kg)"] = weight
df["Calories (kcal)"] = df["Steps"] * step_length * weight * SCALE

# ---------------- DASHBOARD ----------------
if st.button("📊 Show Dashboard"):
    total_steps = df["Steps"].sum()
    total_calories = df["Calories (kcal)"].sum()

    # --------- Calculate new weight after calorie burn ---------
    calories_per_kg = 7700  # kcal per 1 kg body fat
    weight_lost = total_calories / calories_per_kg
    new_weight = max(weight - weight_lost, 0)

    # --------- Beautiful Stat Boxes ---------
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.markdown(f"""
        <div class="metric-box">
            <div class="metric-label">👣 Total Steps</div>
            <div class="metric-value">{total_steps:,}</div>
        </div>
        """, unsafe_allow_html=True)
    with col2:
        st.markdown(f"""
        <div class="metric-box">
            <div class="metric-label">🔥 Total Calories</div>
            <div class="metric-value">{total_calories:.2f}</div>
            <div class="metric-unit">kcal</div>
        </div>
        """, unsafe_allow_html=True)
    with col3:
        st.markdown(f"""
        <div class="metric-box">
            <div class="metric-label">⚖️ Current Weight</div>
            <div class="metric-value">{new_weight:.2f}</div>
            <div class="metric-unit">kg</div>
        </div>
        """, unsafe_allow_html=True)
    with col4:
        st.markdown(f"""
        <div class="metric-box">
            <div class="metric-label">🧬 LostWeight</div>
            <div class="metric-value">-{weight_lost:.3f}</div>
            <div class="metric-unit">kg</div>
        </div>
        """, unsafe_allow_html=True)

    # --------- Optional AI prediction ---------
    try:
        model = joblib.load("calorie_model.joblib")
        X = pd.DataFrame([[total_steps, weight]], columns=['detected_steps', 'weight_kg'])
        ai_cal = model.predict(X)[0]
        st.success(f"🤖 AI Predicted Calories: {ai_cal:.2f} kcal")
    except:
        pass

    # --------- GRAPH ---------
    st.subheader("📈 Activity Graph")

    if len(df) > 1 and df["Steps"].max() > 0:
        df["Time_dt"] = pd.to_datetime(df["Time"], format="%H:%M")
        df = df.sort_values("Time_dt")

        fig, ax = plt.subplots(figsize=(8, 4))
        fig.patch.set_facecolor('white')
        ax.set_facecolor('#f0f8ff')

        ax.plot(df["Time"], df["Steps"], color='#006400', linewidth=3, marker='o', markersize=7, markerfacecolor='#00FF7F')
        ax.fill_between(df["Time"], df["Steps"], color='#90EE90', alpha=0.25)

        ax.set_xlabel("Time of Day", color='#333333')
        ax.set_ylabel("Steps", color='#333333')
        ax.tick_params(colors='#333333')
        ax.set_title("Today's Steps", color='#333333', fontsize=15, fontweight='bold')

        st.pyplot(fig)
    else:
        st.warning("⚠️ Please enter at least two time points with different step values to draw the graph.")

    # --------- Data Table ---------
    df["Current Weight (kg)"] = new_weight
    df["Lost Weight (kg)"] = weight_lost
    st.dataframe(df[["Time", "Steps", "Calories (kcal)", "Current Weight (kg)", "Lost Weight (kg)"]])

else:
    st.info("Enter time and steps, then click **Show Dashboard** to view your results.")

st.caption("Project 17 — AI System for Monitoring Daily Step Count, Calories Burned, and EvoCode LostWeight ⌚")
