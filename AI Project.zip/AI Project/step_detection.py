# step_detection.py
import pandas as pd
import numpy as np
from scipy.signal import find_peaks
import matplotlib.pyplot as plt

def detect_steps_per_minute(df, sampling_hz=50, height=None, distance=None, prominence=0.15):
    """
    df must contain columns: 'time_s', 'accel_mag', 'minute'
    Returns a summary DataFrame: minute, detected_steps
    """
    minutes = sorted(df['minute'].unique())
    results = []
    for m in minutes:
        seg = df[df['minute'] == m]
        mag = seg['accel_mag'].values
        if len(mag) == 0:
            results.append({'minute': m, 'detected_steps': 0})
            continue
        # find peaks; tune prominence/distance for robustness
        # distance in samples to avoid detecting same step multiple times.
        if distance is None:
            distance = int(0.4 * sampling_hz)  # min 0.4s between peaks
        peaks, props = find_peaks(mag, distance=distance, prominence=prominence, height=height)
        results.append({'minute': m, 'detected_steps': len(peaks)})
    return pd.DataFrame(results)

if __name__ == "__main__":
    df = pd.read_csv("sim_data.csv")
    summary = detect_steps_per_minute(df, sampling_hz=50, prominence=0.12)
    merged = pd.merge(summary, pd.read_csv("sim_summary.csv"), on='minute', how='left')
    merged['error_steps'] = merged['detected_steps'] - merged['steps_gt']
    merged.to_csv("detected_steps_summary.csv", index=False)
    print("Saved detected_steps_summary.csv. Here are first lines:")
    print(merged.head())

    # Optional: plot sample minute to visually inspect
    import matplotlib.pyplot as plt
    minute_to_plot = 5
    seg = df[df['minute']==minute_to_plot]
    plt.figure(figsize=(10,3))
    plt.plot(seg['time_s'], seg['accel_mag'], label='accel_mag')
    peaks, _ = find_peaks(seg['accel_mag'].values, distance=int(0.4*50), prominence=0.12)
    plt.plot(seg['time_s'].values[peaks], seg['accel_mag'].values[peaks], "x", label='peaks')
    plt.title(f"Minute {minute_to_plot} accel magnitude + detected peaks")
    plt.xlabel("time (s)")
    plt.legend()
    plt.tight_layout()
    plt.show()
