# model_train.py  (Final crash-proof version)
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import joblib

STEP_LENGTH_M = 0.762
SCALE = 0.0005

def estimate_calories_formula(steps, weight_kg, step_length_m=STEP_LENGTH_M):
    return steps * step_length_m * weight_kg * SCALE

if __name__ == "__main__":
    # Load input CSVs
    try:
        det = pd.read_csv("detected_steps_summary.csv")
        summary = pd.read_csv("sim_summary.csv")
    except Exception as e:
        print("❌ Error loading CSV files:", e)
        print("➡️ Run data_simulation.py and step_detection.py first.")
        raise SystemExit()

    # --- SAFETY PATCHES --------------------------------------------------------
    # Ensure both have 'minute' column
    if 'minute' not in det.columns:
        print("❌ detected_steps_summary.csv missing 'minute' column.")
        raise SystemExit()

    # Add default weight to both files if missing
    if 'weight_kg' not in det.columns:
        det['weight_kg'] = 65
    if 'weight_kg' not in summary.columns:
        summary['weight_kg'] = 65

    # Merge on minute safely
    df = pd.merge(det, summary[['minute', 'weight_kg']], on='minute', how='left')

    # If merge still loses weight_kg, add default
    if 'weight_kg' not in df.columns:
        df['weight_kg'] = 65
    df['weight_kg'] = df['weight_kg'].fillna(65)

    # Add steps_gt if missing
    if 'steps_gt' not in df.columns:
        df['steps_gt'] = df['detected_steps']

    # ---------------------------------------------------------------------------
    # Calculate calories
    df['calories_gt'] = estimate_calories_formula(df['steps_gt'], df['weight_kg'])
    df['calories_from_detected'] = estimate_calories_formula(df['detected_steps'], df['weight_kg'])

    # Train Linear Regression model
    X = df[['detected_steps', 'weight_kg']]
    y = df['calories_gt']
    model = LinearRegression().fit(X, y)
    y_pred = model.predict(X)

    print("\n✅ Model training complete")
    print("MSE:", mean_squared_error(y, y_pred))
    print("R²:", r2_score(y, y_pred))

    joblib.dump(model, "calorie_model.joblib")
    print("💾 Model saved to calorie_model.joblib")

    df['pred_calories_lr'] = model.predict(X)
    df.to_csv("calorie_predictions.csv", index=False)
    print("📄 Saved calorie_predictions.csv successfully")
